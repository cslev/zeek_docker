
#pragma once

// Headers to include by generated BiF code.
#include "analyzer/Analyzer.h"
#include "Conn.h"
#include "NetVar.h"
#include "Event.h"
#include "Reporter.h"
#include "Var.h" // for internal_type()
